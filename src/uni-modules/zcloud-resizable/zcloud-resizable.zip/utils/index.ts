export const resizeUUID = { value: 1 }
