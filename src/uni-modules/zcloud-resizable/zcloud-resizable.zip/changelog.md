# 更新日志

### 1.0.0 (2025-07-06)

### ✨ Bugs | 缺陷

- 🐛 修复尺寸为小数时频繁触发 resize 的问题

### 1.0.0 (2025-06-26)

### ✨ Features | 新功能

- ⚡ 增加首次渲染触发 resize 事件配置 emitWhenMounted
- ⚡ 增加 className styles 配置

### 1.0.0 (2025-06-24)

### ✨ Features | 新功能

- ⚡ 添加 zcoud-resizable 组件
